import Content from "./Content"

const Movies:React.FC = () => {
  return (
    <Content type="movie"/>
  )
}

export default Movies