import Content from "./Content"

const Tvs:React.FC = () => {
  return (
    <Content type="tv"/>
  )
}

export default Tvs