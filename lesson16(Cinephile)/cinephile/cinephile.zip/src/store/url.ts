export const apiUrl:string = 'https://api.themoviedb.org/3/';
export const apiKey:string = '71cb2676f355bd5674fbe977b8b7fb4b';
export const imageFull:string = 'https://image.tmdb.org/t/p/original/';
export const imageMini:string = 'https://image.tmdb.org/t/p/w500/';

