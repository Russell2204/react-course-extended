import Content from "components/Content/Content"

const MoviesPage = () => {
    return (
      <Content type="movie"/>
    )
  }
  
  export default MoviesPage