const SearchPage = () => {
    return (
      <div>SearchPage</div>
    )
  }
  
  export default SearchPage