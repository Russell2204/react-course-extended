import Content from "components/Content/Content"

const TvsPage = () => {
    return (
      <Content type="tv"/>
    )
  }
  
  export default TvsPage